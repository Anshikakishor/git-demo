n=int(input("Enter the number of names:\n"))
l=[]
if n>0:
    print("Enter the names:")
    for i in range(n):
        l.append(input())
    print("The sorted name list is:")
    l.sort(reverse=True)
    l.sort(reverse=True, key=len)

    i=0
    while i<n:
        print(l[i])
        i+=1
        continue
else:
    print("Invalid Input")
